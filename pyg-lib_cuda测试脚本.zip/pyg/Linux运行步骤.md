# pyg-lib 文档用例：Linux 容器运行

源码目录：`<pyg_home>`。先把本目录的 `geometry.py`、`spline.py`、`subgraph.py` 分别覆盖到该源码的 `benchmark/ops/geometry.py`、`benchmark/ops/spline.py`、`benchmark/sampler/subgraph.py`。

## 1. 检查源码及原生库

```bash
cd <pyg_home>
test -f setup.py && test -f benchmark/ops/geometry.py
test -f third_party/METIS/GKlib/GKlibSystem.cmake
test -f third_party/METIS/libmetis/CMakeLists.txt
test -f third_party/parallel-hashmap/parallel_hashmap/phmap.h
python - <<'PY'
import pathlib, torch, pyg_lib
root = pathlib.Path('<pyg_home>').resolve()
print('torch:', torch.__version__, 'CUDA:', torch.cuda.is_available())
print('pyg_lib:', pyg_lib.__file__)
print('same source:', pathlib.Path(pyg_lib.__file__).resolve().is_relative_to(root))
print('native lib:', list((root / 'pyg_lib').glob('libpyg*.so')))
print('CPU subgraph:', torch._C._dispatch_has_kernel_for_dispatch_key('pyg::subgraph', 'CPU'))
PY
```

若任一 `test -f` 失败或没有 `libpyg*.so`，先补齐源码依赖并构建原生库。这个源码的 `setup.py` 使用 CMake 构建 CPU/CUDA 扩展。容器不能下载依赖时，先在宿主机补齐源码后再安装，不要把未加载原生库的 Python 包当作测试通过。

```bash
python -m pip install --no-build-isolation --no-deps -e .
```

## 2. CPU 子图

此源码只注册了 subgraph 的 CPU 实现。每个 shape 测 int32 图索引，共输出 8 行。

```bash
cd <pyg_home>
mkdir -p /home/w30081820/perf_results
set -o pipefail
python -u benchmark/sampler/subgraph.py --device cpu --warmup 20 --iter 100 \
  2>&1 | tee /home/w30081820/perf_results/pyg_subgraph_cpu.log
echo "运行退出码：$?"
```

## 3. CUDA 几何和采样算子

```bash
python -u benchmark/ops/geometry.py --device cuda --warmup 20 --iter 100 \
  2>&1 | tee /home/w30081820/perf_results/pyg_geometry_cuda.log
echo "运行退出码：$?"
```

## 4. CUDA 样条算子

```bash
python -u benchmark/ops/spline.py --device cuda --warmup 20 --iter 100 \
  2>&1 | tee /home/w30081820/perf_results/pyg_spline_cuda.log
echo "运行退出码：$?"
```

三组输出均为单次平均毫秒数。geometry 的浮点输入只测 `float32`，random_walk 与 subgraph 的图索引只测 `int32`；graclus_cluster 的图索引按其 CUDA 实现保持 `int64`，边权只测 `float32`。geometry 中尺寸最大的一些场景可能需要较大的 GPU 显存；若出现 OOM，请保留具体算子、行号和 dtype，不将其计为有效结果。本次 CUDA spline 只测 `float32`，原用例文档中的 NPU fp16 测试不包含在本次 CUDA 结果中。
