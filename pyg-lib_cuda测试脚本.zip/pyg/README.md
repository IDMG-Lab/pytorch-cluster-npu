修改后的代码已经写入 pyg-lib 实际仓库，路径对应如下：

| 此目录文件 | 仓库路径 |
|---|---|
| `spline.py` | `benchmark/ops/spline.py`，修改原有入口 |
| `subgraph.py` | `benchmark/sampler/subgraph.py`，修改原有入口 |
| `geometry.py` | `benchmark/ops/geometry.py`，补充原 benchmark 中缺少的 7 类算子 |

实际仓库根目录：`C:\Users\w30081820\Downloads\pyg-lib-main\pyg-lib-main`。这些文件在根目录下的 `benchmark` 文件夹内，而非 `pyg_lib` 包目录。`*_original.py` 是修改前的原始文件备份。

在安装或构建好本仓库的 pyg-lib 后，从根目录运行：

```bash
python benchmark/ops/geometry.py --device cuda
python benchmark/ops/spline.py --device cuda
python benchmark/sampler/subgraph.py --device cpu
```

三个入口仅列出性能文档的 Shape；原有通用 spline 场景及 subgraph 数据集对比已停用并注明。`--case` 可选择零起始行号，`--warmup` 默认 20，`--iter` 默认 100。当前仓库的 subgraph 只注册了 CPU 实现。CUDA 几何算子的浮点输入及 spline 只测 `float32`；random_walk 与 CPU subgraph 的图索引只测 `int32`。graclus_cluster 的图索引按其 CUDA 实现保持 `int64`，边权只测 `float32`。原用例文档要求在 NPU 上测 spline fp16/fp32。

fps 用单批次 ptr 表示文档的无 batch 场景；graclus/random_walk 将文档的 COO 边规模转换成该库接口要求的 CSR。graclus 的测试图使用双向边和成对相同的边权。文档未给出具体数值的参数当前采用 fps ratio=0.5、knn k=8、radius r=0.5/max_num_neighbors=32，随机游走节点数为 E/4。

已验证语法并核对 task 副本与仓库文件一致。
