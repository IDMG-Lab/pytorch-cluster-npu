"""Summary-only cases for pyg-lib geometry and graph sampling operators.

These operators have functional tests in test/ops, but no corresponding
performance file under benchmark/ops. Run from the repository root. The
summary's None batch/COO inputs are converted to the one-batch pointer and
CSR representations required by pyg-lib's fps, graclus and random_walk APIs.
"""

import argparse
import time

import torch
import pyg_lib

K = 1024
M = K * K
CASES = {
    'fps': [(16000, 128), (16384, 4), (1024, 16), (1024, 32),
            (4096, 16), (4096, 32), (4096, 64),
            (8192, 16), (8192, 32), (8192, 64)],
    'grid_cluster': [(n*M, d) for n in (1, 4, 8, 32) for d in (16, 32, 64)],
    'knn': [(4096, 128), (8192, 256), (10000, 3), (20000, 128),
            (32000, 3), (4096, 32), (8192, 32), (16384, 32), (8192, 64)],
    'nearest': [(20000, 10000, 128), (8192, 8192, 3),
                (32768, 32768, 16), (32768, 32768, 32),
                (32768, 32768, 64), (4096, 1024, 3),
                (8192, 4096, 3), (16384, 8192, 3), (32768, 16384, 3)],
    'graclus_cluster': [(10000, 50000), (5000, 10000),
                        (128, 16256), (256, 65280), (512, 261120),
                        (1024, 1046528), (2048, 4192256),
                        (4096, 16773120), (500000, 2000000),
                        (1000000, 4000000)],
    'radius': [(n*K, 3) for n in (8, 16, 32, 64, 128, 256, 512, 1024)],
    'random_walk': [(e*K, s*K, length) for e, s, length in [
        (512, 32, 64), (512, 32, 128), (512, 32, 256),
        (1024, 64, 128), (1024, 64, 256), (1024, 64, 512),
        (2048, 128, 128), (2048, 128, 256),
        (4096, 128, 128), (4096, 128, 256), (4096, 256, 512)]],
}


def sync(device):
    if device.type == 'npu':
        torch.npu.synchronize(device)
    elif device.type == 'cuda':
        torch.cuda.synchronize(device)


def csr(n, e, device, index_dtype=torch.int64):
    counts = torch.full((n,), e // n, dtype=index_dtype)
    counts[:e % n] += 1
    rowptr = torch.empty(n + 1, dtype=index_dtype)
    rowptr[0] = 0
    rowptr[1:] = counts.cumsum(0)
    col = torch.randint(n, (e,), dtype=index_dtype)
    return rowptr.to(device), col.to(device)


def undirected_csr(n, e, device, weight_dtype):
    if e % 2:
        raise ValueError('graclus requires an even edge count for symmetric pairs')
    half = e // 2
    src = torch.randint(n, (half,), dtype=torch.int64)
    dst = torch.randint(n - 1, (half,), dtype=torch.int64)
    dst += (dst >= src).to(torch.int64)
    rows = torch.cat((src, dst))
    cols = torch.cat((dst, src))
    weights = torch.rand(half, dtype=weight_dtype).repeat(2)
    order = rows.argsort()
    counts = torch.bincount(rows, minlength=n)
    rowptr = torch.empty(n + 1, dtype=torch.int64)
    rowptr[0] = 0
    rowptr[1:] = counts.cumsum(0)
    return rowptr.to(device), cols[order].to(device), weights[order].to(device)


def make_call(op, case, dtype, device):
    if op == 'fps':
        n, d = case
        pos = torch.rand(n, d, dtype=dtype, device=device)
        ptr = torch.tensor([0, n], dtype=torch.int64, device=device)
        return lambda: pyg_lib.ops.fps(pos, ptr, 0.5, False)
    if op == 'grid_cluster':
        n, d = case
        pos = torch.rand(n, d, dtype=dtype, device=device)
        size = torch.full((d,), .01, dtype=dtype, device=device)
        start = torch.zeros(d, dtype=dtype, device=device)
        end = torch.ones(d, dtype=dtype, device=device)
        return lambda: pyg_lib.ops.grid_cluster(pos, size, start, end)
    if op == 'knn':
        x = torch.rand(case, dtype=dtype, device=device)
        return lambda: pyg_lib.ops.knn(x, x, 8)
    if op == 'nearest':
        n, m, d = case
        x = torch.rand(n, d, dtype=dtype, device=device)
        y = torch.rand(m, d, dtype=dtype, device=device)
        return lambda: pyg_lib.ops.nearest(x, y)
    if op == 'radius':
        x = torch.rand(case, dtype=dtype, device=device)
        return lambda: pyg_lib.ops.radius(x, x, .5, max_num_neighbors=32)
    if op == 'graclus_cluster':
        n, e = case
        rowptr, col, weight = undirected_csr(n, e, device, dtype)
        return lambda: pyg_lib.ops.graclus_cluster(rowptr, col, weight)
    e, starts, length = case
    n = e // 4
    rowptr, col = csr(n, e, device, dtype)
    seed = torch.arange(starts, dtype=dtype, device=device) % n
    return lambda: pyg_lib.sampler.random_walk(rowptr, col, seed, length)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--op', choices=('all', *CASES), default='all')
    parser.add_argument('--device', default='cuda')
    parser.add_argument('--warmup', type=int, default=20)
    parser.add_argument('--iter', type=int, default=100)
    parser.add_argument('--case', type=int, help='zero-based row index')
    args = parser.parse_args()
    if args.warmup < 0 or args.iter <= 0:
        parser.error('--warmup must be nonnegative and --iter positive')
    device = torch.device(args.device)
    if device.type == 'npu':
        import torch_npu  # noqa: F401
    for op, cases in CASES.items():
        if args.op not in ('all', op):
            continue
        for row, case in enumerate(cases):
            if args.case is not None and args.case != row:
                continue
            dtypes = ((torch.int32,) if op == 'random_walk'
                      else (torch.float32,))
            for dtype in dtypes:
                print(f'START {op}\t{row}\t{case}\t{dtype}', flush=True)
                fn = make_call(op, case, dtype, device)
                print(f'READY {op}\t{row}\t{case}\t{dtype}', flush=True)
                try:
                    with torch.no_grad():
                        for _ in range(args.warmup):
                            fn()
                        sync(device)
                        start = time.perf_counter()
                        for _ in range(args.iter):
                            fn()
                        sync(device)
                except (RuntimeError, NotImplementedError) as exc:
                    print(f'{op}\t{row}\t{case}\tUNSUPPORTED: {exc}', flush=True)
                    continue
                ms = 1000 * (time.perf_counter() - start) / args.iter
                print(f'{op}\t{row}\t{case}\t{dtype}\t{ms:.6f} ms', flush=True)


if __name__ == '__main__':
    main()
