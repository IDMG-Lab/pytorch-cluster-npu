"""Documented spline performance cases for pyg-lib.

Replaces the generic E=10000 and combined autograd cases in the repository's
benchmark/ops/spline.py. Only explicit forward/backward operators are timed.
"""

import argparse
import time

import torch
import pyg_lib  # noqa: F401 - registers torch.ops.pyg

# Disabled original cases: E=10000, D=3, degrees 1/2/3 and combined
# forward+autograd timings; E=10000 weighting comparisons.

K = 1024
OPS = {
    'basis': [(64*K, 3, 1), (16*K, 1, 1), (16*K, 1, 3),
              (16*K, 2, 1), (16*K, 2, 3), (16*K, 3, 2),
              (16*K, 3, 3), (16*K, 4, 2)],
    'basis_backward': [(16*K, 3, 1), (64*K, 3, 1), (16*K, 2, 3),
                       (16*K, 3, 2), (16*K, 3, 3), (16*K, 4, 2)],
    'weighting': [(16*K, 8, 16, 125, 8), (64*K, 8, 16, 125, 8),
                  (16*K, 32, 16, 125, 8), (16*K, 64, 16, 125, 8),
                  (16*K, 128, 16, 125, 8), (16*K, 8, 128, 125, 8),
                  (16*K, 8, 16, 1024, 8), (16*K, 8, 16, 125, 64)],
    'weighting_backward_weight': [(64*K, 8, 16, 125, 8),
                                  (16*K, 128, 16, 125, 8),
                                  (16*K, 8, 32, 125, 8),
                                  (16*K, 8, 64, 125, 8),
                                  (16*K, 8, 128, 125, 8),
                                  (16*K, 8, 16, 1024, 8),
                                  (16*K, 8, 16, 125, 64)],
    'weighting_backward_x': [(64*K, 8, 16, 125, 8),
                             (16*K, 32, 16, 125, 8),
                             (16*K, 64, 16, 125, 8),
                             (16*K, 128, 16, 125, 8),
                             (16*K, 8, 32, 125, 8),
                             (16*K, 8, 64, 125, 8),
                             (16*K, 8, 16, 1024, 8),
                             (16*K, 8, 16, 125, 64)],
    'weighting_backward_basis': [(64*K, 8, 16, 125, 8),
                                 (16*K, 1, 16, 125, 8),
                                 (16*K, 8, 64, 125, 8),
                                 (16*K, 8, 128, 125, 8),
                                 (16*K, 8, 16, 1, 8),
                                 (16*K, 8, 16, 1024, 8),
                                 (16*K, 8, 16, 125, 64)],
}


def synchronize(device):
    if device.type == 'npu':
        torch.npu.synchronize(device)
    elif device.type == 'cuda':
        torch.cuda.synchronize(device)


def latency(fn, device, warmup, iterations):
    with torch.no_grad():
        for _ in range(warmup):
            fn()
        synchronize(device)
        start = time.perf_counter()
        for _ in range(iterations):
            fn()
        synchronize(device)
    return 1000 * (time.perf_counter() - start) / iterations


def make_call(op, shape, dtype, device):
    if op.startswith('basis'):
        e, d, degree = shape
        pseudo = torch.rand(e, d, dtype=dtype, device=device)
        kernel = torch.full((d,), 5, dtype=torch.int64, device=device)
        opened = torch.tensor([i % 2 for i in range(d)],
                              dtype=torch.uint8, device=device)
        if op == 'basis':
            return lambda: torch.ops.pyg.spline_basis(pseudo, kernel, opened, degree)
        grad = torch.rand(e, (degree + 1) ** d, dtype=dtype, device=device)
        return lambda: torch.ops.pyg.spline_basis_backward(grad, pseudo, kernel, opened, degree)
    e, mi, mo, kernels, s = shape
    x = torch.rand(e, mi, dtype=dtype, device=device)
    weight = torch.rand(kernels, mi, mo, dtype=dtype, device=device)
    basis = torch.rand(e, s, dtype=dtype, device=device)
    index = torch.randint(kernels, (e, s), dtype=torch.int64, device=device)
    if op == 'weighting':
        return lambda: torch.ops.pyg.spline_weighting(x, weight, basis, index)
    grad = torch.rand(e, mo, dtype=dtype, device=device)
    if op == 'weighting_backward_weight':
        return lambda: torch.ops.pyg.spline_weighting_backward_weight(grad, x, basis, index, kernels)
    if op == 'weighting_backward_x':
        return lambda: torch.ops.pyg.spline_weighting_backward_x(grad, weight, basis, index)
    return lambda: torch.ops.pyg.spline_weighting_backward_basis(grad, x, weight, index)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--op', choices=('all', *OPS), default='all')
    parser.add_argument('--device', default='cuda')
    parser.add_argument('--warmup', type=int, default=20)
    parser.add_argument('--iter', type=int, default=100)
    parser.add_argument('--case', type=int, help='zero-based row index')
    args = parser.parse_args()
    if args.warmup < 0 or args.iter <= 0:
        parser.error('--warmup must be nonnegative and --iter positive')
    device = torch.device(args.device)
    if device.type == 'npu':
        import torch_npu  # noqa: F401
    for op, shapes in OPS.items():
        if args.op not in ('all', op):
            continue
        for row, shape in enumerate(shapes):
            if args.case is not None and args.case != row:
                continue
            for dtype in (torch.float32,):
                print(f'START {op}\t{row}\t{shape}\t{dtype}', flush=True)
                fn = make_call(op, shape, dtype, device)
                try:
                    ms = latency(fn, device, args.warmup, args.iter)
                except (RuntimeError, NotImplementedError) as exc:
                    print(f'{op}\t{row}\t{shape}\t{dtype}\tUNSUPPORTED: {exc}', flush=True)
                    continue
                print(f'{op}\t{row}\t{shape}\t{dtype}\t{ms:.6f} ms', flush=True)


if __name__ == '__main__':
    main()
